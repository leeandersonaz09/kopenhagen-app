const fonts = {
    input: 16,
    regular: 15,
    medium: 12,
    small: 11,
    tiny: 10,
    headerTittle: 18,
    header: 20,
    big: 38
  };
  
  export default fonts;