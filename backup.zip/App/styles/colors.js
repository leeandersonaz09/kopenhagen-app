const colors = {
  header: '#333333',
  primary: '#fbd1d2',
  gray: '#d8d8d8',
  white: '#fff',
  yellow: "#ffcc00",
  black: '#000',
  red: '#ab1d58',
  blue: '#483d8b',
  facebook: '#4267B2',
  brown:'#261a13',
  brown2:'#b88a53',
  secondary:'#ad8878',
  green:"#075e54"


};

export default colors;